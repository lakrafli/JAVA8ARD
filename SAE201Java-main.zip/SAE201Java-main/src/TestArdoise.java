import ardoise.* ;
public class TestArdoise {
	public static void main(String  []args) {
		Ardoise ardoise = new Ardoise();
		ardoise.test();
		
	}
}